package annotation_based;

public class Teacher {

	private String name;
	
	
	public Teacher(){
		System.out.println("Inside Teacher Constructor");
	}
	
	
	
}
