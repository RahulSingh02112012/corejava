package Collections;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionsFile {

	private List numberList;
	private Set  mobileSet;
	private Map addressMap;
	private Properties prop;
	public List getNumberList() {
		return numberList;
	}
	public void setNumberList(List numberList) {
		this.numberList = numberList;
	}
	public Set getMobileSet() {
		return mobileSet;
	}
	public void setMobileSet(Set mobileSet) {
		this.mobileSet = mobileSet;
	}
	public Map getAddressMap() {
		return addressMap;
	}
	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}
	public Properties getProp() {
		return prop;
	}
	public void setProp(Properties prop) {
		this.prop = prop;
	}
	
	
	
}

