package beanLifecycle;

import annotation_based.AnnotationConfig;
import annotation_based.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;

@Configuration
public class SpringBeanLifecycleApplication {


    private AwareBeanImpl awareBean;
    private BookBean bookBean;
    private Book book;

    @Bean
    public BookBean getBookBean() {
        return bookBean;
    }

    @Bean
    public Book getBook() {
        return book;
    }

    @Bean
    public AwareBeanImpl getAwareBean() {
        return awareBean;
    }

    public static void main(String[] args) {
        //https://dzone.com/articles/spring-bean-lifecycle
        AbstractApplicationContext ctx = new AnnotationConfigApplicationContext(SpringBeanLifecycleApplication.class);
        AwareBeanImpl std = (AwareBeanImpl) ctx.getBean(AwareBeanImpl.class);
        System.out.println(std);
        BookBean bookbean = (BookBean) ctx.getBean(BookBean.class);

        Book book = ctx.getBean(Book.class);
        ctx.registerShutdownHook();
    }
}
