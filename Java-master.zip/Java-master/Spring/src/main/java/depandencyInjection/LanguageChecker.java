package depandencyInjection;

public class LanguageChecker {

	public LanguageChecker(){
		System.out.println("Inside Language Checker constructor");
	}
	
	public void checkLanguage(){
		System.out.println("Inside Language Checker method");
	}
}
