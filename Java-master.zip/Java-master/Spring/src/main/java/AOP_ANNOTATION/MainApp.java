package AOP_ANNOTATION;

import annotation_based.AnnotationConfig;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainApp {

	@Bean
	public Student getStudent() {
		return student;
	}


	private Student student;
	public static void main(String[] args) {
		//ApplicationContext context = new ClassPathXmlApplicationContext("Beans4.xml");

		ApplicationContext ctx = new AnnotationConfigApplicationContext(AnnotationConfig.class);

	      Student student = (Student) ctx.getBean(Student.class);

		//Create the Proxy Factory
		AspectJProxyFactory proxyFactory = new AspectJProxyFactory(student);
		//Add Aspect class to the factory
		proxyFactory.addAspect(Logging.class);

//Get the proxy object
		Student proxyStudent = proxyFactory.getProxy();

//Invoke the proxied method.
		proxyStudent.getAge();

	      
	     student.printThrowException();

	}

}
