package Lambda_Expression;

public interface CustomFunctionalInterface {

	public void show(int number,int digit);
	
}
