package Lambda_Expression;
@FunctionalInterface
public interface MyInterface {

	public abstract int sumMethod(int i, int j);
	//public abstract int sumMethod1(int i, int j);
}
