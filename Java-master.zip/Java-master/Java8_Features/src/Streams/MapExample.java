package Streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MapExample {

    public static void main(String[] args) {

        Stream<String> stream = Stream.of("one","two","three","eleven","tewlveee");

        Function<String,String> function = x->{return x.toUpperCase();};
        stream.map(function).forEach(x->System.out.println(x));


        List<String> Lists = Stream.of(Arrays.asList("1","2","4"),Arrays.asList("7","5","4"),Arrays.asList("11","24","44")).
                flatMap(list1->list1.stream()).collect(Collectors.toList());

        Lists.forEach(x->System.out.print(" "+x));
        System.out.println();
    }
}
