package Streams;

import java.util.function.Predicate;
import java.util.stream.Stream;

public class FilterExample {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("one","two","three","eleven","tewlveee");

        Predicate<String> pred = x-> x.length()>3;
      stream.filter(pred).forEach(x->System.out.println(x));
      //  stream.forEach(x->System.out.println(x));
       // System.out.print(stream1);
        Predicate<String> pred2 = x-> x.startsWith("t");
       Stream<String> stream2 = stream.filter(pred.and(pred2));
       // Chaining

    }
}
