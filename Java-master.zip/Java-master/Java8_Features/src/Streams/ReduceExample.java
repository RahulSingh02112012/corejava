package Streams;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.stream.Stream;

public class ReduceExample {

    public static void main(String[] args) {
        Stream<Integer> stream = Stream.of(1,2,3,4);
        BinaryOperator<Integer> biFunction = (Integer x, Integer y)->{return x+y;};
        /* Internal working of reduce function
         T result = identity;
          for (T element : this stream)
         result = accumulator.apply(result, element)
         return result;
 */
        Integer sum = stream.reduce(0,biFunction);
        System.out.println(sum);

// if stream is empty then reduce will return indentity
        Stream<Integer> stream2 = Stream.empty();
        Integer sum2 = stream2.reduce(0,(val1,val2)->val1+val2);
        System.out.println(sum2);

// if stream has 1 value then it return that value

        Stream<Integer> stream3 = Stream.of(3);
        Integer sum3 = stream3.reduce(0,(val1,val2)->val1+val2);
        System.out.println(sum3);
    }
}
