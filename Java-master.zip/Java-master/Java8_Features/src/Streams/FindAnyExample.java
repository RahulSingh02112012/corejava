package Streams;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class FindAnyExample {
    public static void main(String[] args) {
        /*There are instances when the business specification says that any element of the stream satisfying a
         given criteria is to be fetched. I.e. an exact element match is not needed but any element from the satisfying
          set can be picked up. In such cases findAny() method is an ideal fit because once you filter the stream down to
          elements satisfying a particular criteria, then any element from the filtered stream can be picked up.*/

        Stream<String> stream = Stream.of("one","two","three","eleven","tewlveee");
        Predicate<String> pred = x-> x.length()>3;
        Optional<String> val =stream.filter(pred).findAny();
        System.out.println(val.get());
    }
}
