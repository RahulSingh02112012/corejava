package Streams;

import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.Stream;

public class FlatMapExample {

    public static void main(String[] args) {
        Stream<Integer> stream1 =  Arrays.asList(1,2,4).stream();
        Stream<Integer> stream2 =  Arrays.asList(6,8,9).stream();
        Stream<Integer> stream3 =  Arrays.asList(11,12,14).stream();

        Stream<Stream<Integer>> streamOfStream = Stream.of(stream1,stream2,stream3);
        Function<Stream<Integer>,Stream<Integer>> function = (x)->{
            return x.filter(y->{
                return y % 2 == 0;
            });
        };

        Stream<Integer> res = streamOfStream.flatMap(function);
        res.forEach(x->System.out.print(" "+x));
    }
}
