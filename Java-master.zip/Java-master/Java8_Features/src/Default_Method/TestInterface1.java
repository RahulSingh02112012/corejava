package Default_Method;

import java.io.File;
import java.nio.file.Files;
import java.util.Base64;

public class TestInterface1 implements Interface1{

	public static void main(String[] args) {
		Interface1 obj = new TestInterface1();
		obj.display();
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
		
		
	
	}


