package Default_Method;

public interface Interface2 {
	default void display2(){
		System.out.println("Default method in INterface2");
	}
}
