package Default_Method;

public class Interface1Test implements Interface1 {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

}
