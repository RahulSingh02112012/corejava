package Static_Method;

public class TestStaticInterface {

	public static void main(String[] args) {
		Interface1.display();
		System.out.println(Interface1.sum(10, 20));

	}

}
