import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.function.Function;

public class Test3 {

	public static void main(String[] args) {
//		LocalDateTime dtDateTime = LocalDateTime.ofInstant(Instant.ofEpochSecond(Long.parseLong("599")), ZoneId.systemDefault());
//		System.out.println(dtDateTime);
		

		// (3).Function which takes in a number and returns half of it
		Function<Integer,Double> func = (Integer y)->y/2.0;
// (2).It Executes After Func
		func = func.andThen(x->x*4);

		// (1).It Executes Before Func
		func = func.compose(x->x*x);


		// 3.apply the function to get the result
		System.out.println(func.apply(10));

	}

}
