package Functional_Interface;

import java.util.Objects;

public class User2 {
    private String name;
    private Integer age;

    public User2(String name, Integer age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User2{" +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                '}';
    }

    public Integer getAge() {
        return age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User2 user2 = (User2) o;
        return name.equals(user2.name) && age.equals(user2.age);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age);
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
