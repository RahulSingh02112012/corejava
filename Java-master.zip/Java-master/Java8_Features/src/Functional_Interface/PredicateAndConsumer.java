package Functional_Interface;

;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class PredicateAndConsumer {

    public static void main(String[] args) {
        List<String> strings = new ArrayList<String>();
        strings.add("One");
        strings.add("Two");
        strings.add("Three");
        strings.add("Four");

        //Qustion- Display only starts with T
        Predicate<String> pred = (String s)->!s.startsWith("T");
        strings.removeIf(pred);

        Consumer<String> cons = (String s)-> System.out.println(s);
        strings.forEach(cons);
    }
}
