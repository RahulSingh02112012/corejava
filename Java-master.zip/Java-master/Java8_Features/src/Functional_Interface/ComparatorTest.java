package Functional_Interface;

import java.util.*;
import java.util.function.Function;

public class ComparatorTest {

	
	public static void main(String[] args) {
		  String[] str={"add","aa","abdd","as"};
		
//1. Compare Using Local Class
		class StringSort implements Comparator<String>{

			@Override
			public int compare(String o1, String o2) {
				// TODO Auto-generated method stub
				return o1.compareTo(o2);
			}
			
		}
		Arrays.sort(str, new StringSort());
		
		
//2. Sort Using Anonymous Inner Class
		
		Arrays.sort(str, new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				// TODO Auto-generated method stub
				return o1.compareTo(o2);
			}
			
		});
		
//3. Sort Using Lambda Expression 
		
		Arrays.sort(str,(String o1,String o2) ->{ 
			return o1.compareTo(o2);
		}
	  );
		
// More Simplified 
		Arrays.sort(str ,(a,b)-> a.compareTo(b));
		
		List<String> asList = Arrays.asList(str);

		Comparator<String> comp= (String s1, String s2)->s1.compareTo(s2);
		Collections.sort(asList,comp);
		System.out.println(asList);

		Function<String,Integer> func= (String s)->s.length();
		Comparator<String> comp2 = Comparator.comparing(func);
		asList.sort(comp2);
		System.out.println(asList);


 // Comparator Chaining
      List<User2> users = new ArrayList<>();
      users.add(new User2("Ajay",30));
		users.add(new User2("Ajay",32));
		users.add(new User2("ZRajiv",34));
		users.add(new User2("Sumit",37));

		Comparator<User2> comp3 = Comparator.comparing(user2 -> user2.getName());
		Comparator<User2> comp4 = Comparator.comparing(user2 -> user2.getAge());
		Comparator<User2> comp5 = comp3.thenComparing(comp4);
		users.sort(comp5);
		users.forEach(x->System.out.println(x));

	}

}
