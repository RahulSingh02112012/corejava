package Functional_Interface;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class FunctionExample {
    public static void main(String[] args) {

        List<User> users = new ArrayList<>();
        users.add(new User("Ajay"));
        users.add(new User("Amit"));
        users.add(new User("Sumit"));
        users.add(new User("Rajiv"));

        List<String> names = new ArrayList<>();

        Function<User,String> func = (User user)->user.getName();
        for (User user:users){
            String name = func.apply(user);
            names.add(name);
        }
        Consumer<User> cons= action->System.out.println(action);
        Consumer<String> cons2= action->System.out.println(action);
        users.forEach(cons);
        names.forEach(cons2);

    }
}
