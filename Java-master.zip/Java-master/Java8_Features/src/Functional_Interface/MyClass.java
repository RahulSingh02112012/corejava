package Functional_Interface;

import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class MyClass {

	public static void main(String[] args) {


		/*Implement Functional Interface Using Lambda Expression*/
		MyInterface my = (a)->System.out.println(a);
		;
		my.display(10);
		//my.display();

		/*Implement Functional Interface Using Annonymous Inner Class*/
		/*MyInterface my1 = new MyInterface() {
			
			@Override
			public void display() {
				System.out.println("HI 1");
				
			}
		};*/
		Supplier<String> str = ()->{return "HI";};
		str.get();
		//my1.display();
		my.display(10);
		//my.show();
		
		MyInterface.view();

		Function<String,Integer> func = (String s)->{
			return Integer.valueOf(s);
		};
		System.out.print(func.apply("10"));

	}

}
