package LinkedList;

public class MergeTwoSortedList {

	public static void main(String[] args) {
		LinkedList listA = new LinkedList();
		listA.add(1);
		listA.add(2);
		//listA.add(3);
		listA.add(4);
		listA.display();
		LinkedList listB = new LinkedList();
		listB.add(1);
		listB.add(3);
	//	listB.add(5);
		//listB.add(6);
		listB.add(4);
		System.out.println();
		listB.display();
		LinkedList listC =mergeList(listA, listB);
		//Node listC1 =mergeTwoLists(listA, listB);
		System.out.println();
		listC.display();


	}
	
	
	public static LinkedList mergeList(LinkedList A ,LinkedList B){
		
		LinkedList C = new LinkedList();
		
		LinkedList.Node a1 = A.head;
		LinkedList.Node b1 = B.head;
	
		
		while(true){
			if(a1==null){
				C.add(b1.data);
				if(b1.next==null){
					break;
				}else{
					b1=b1.next;
				}
				
			}
			if(b1 == null){
				C.add(a1.data);
				if(a1.next==null){
				break;
				}else{
					b1=b1.next;
				}
			}
			if(a1!=null && b1!=null){
			if(a1.data <= b1.data){
				C.add(a1.data);
				a1 = a1.next;
			}else{
				C.add(b1.data);
				b1 = b1.next;
			}
			}
			//c1 = c1.next;
		}
			
		return C;
	}

	/*public static Node mergeTwoLists(LinkedList a, LinkedList b) {
		LinkedList.Node list1 = a.head;
		LinkedList.Node list2 = b.head;
		LinkedList new_node = new LinkedList();
		while(list1!=null && list2!=null){
			if(list1.data<list2.data){
				new_node.head.data = list1.data;
				//new_node.next = new Node();
				new_node = new_node.next;
				list1 = list1.next;
			}else{
				new_node.data = list2.data;
				//new_node.next = new Node();
				new_node = new_node.next;
				list1 = list2.next;
			}
		}
		while(list1!=null){
			new_node.data = list1.data;
		//	new_node.next = new Node();
			new_node = new_node.next;
			list1 = list1.next;
		}
		while(list2!=null){
			new_node.data = list2.data;
		//	new_node.next = new Node();
			new_node = new_node.next;
			list2 = list2.next;
		}
		return new_node;
	}*/

}
