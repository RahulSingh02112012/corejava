package Tree;

public class TreeNode {

	int val;
	TreeNode left;
	TreeNode right;
	
	public TreeNode(int data){
		this.val = data;
		this.left = null;
		this.right = null;
	}
	
}
