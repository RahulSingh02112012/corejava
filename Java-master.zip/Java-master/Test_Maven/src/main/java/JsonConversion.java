import org.apache.commons.lang.StringUtils;
import org.apache.poi.util.SystemOutLogger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class JsonConversion {
    public static void main(String[] args) throws IOException {
      /*  String jsonString ="{\"webSite\":null,\"types\":[\"SITE_PHYSICAL_ADDRESS\"],\"addresses\":[{\"identity\":{\"id\":\"SWBLQMLTV3RXPRHSL0VBZLC7SC\",\"name\":\"MeenaStoreContactName_IRAaE0WZQRG24\",\"description\":\"Meena Site Contact Name Desc\",\"code\":null},\"type\":\"BUSINESS\",\"formattedAddress\":null,\"addressLine1\":\"900 ShoreLIne Blvd\",\"addressLine2\":\"\",\"addressLine3\":null,\"city\":\"New York City\",\"state\":\"NY\",\"zipCode\":\"61845-0615\",\"country\":\"USA\",\"longitude\":null,\"latitude\":null,\"isAddressValidated\":true,\"skipMelissaData\":null}],\"preferences\":\"Email\",\"emailAddresses\":[{\"id\":\"2LG379AYQ3QRF0CKZKY3425VQ8\",\"emailAddress\":\"MeenaAMPLNYKP9@gmail.com\",\"type\":\"WORK\"}],\"identity\":{\"id\":\"15XD4LYPFZPH007HZBK666XA48\",\"name\":\"MeenaStoreContactName_IRAaE0WZQRG24_PhysicalAddress\",\"description\":\"MeenaSiteContactName - Physical Address Contact Stoneridge Mall\",\"code\":null},\"instantMessengers\":[],\"links\":[{\"rel\":\"self\",\"href\":\"https:\\/\\/int.blackhawknetwork.com\\/channel\\/v1\\/clients\\/QC00YVXGYKDRZ4ML8DP1LJR1GM\\/sites\\/A2QJ37C4M7JTYGD1P2P2FVH690\\/contacts\\/15XD4LYPFZPH007HZBK666XA48\",\"hreflang\":null,\"media\":null,\"title\":null,\"type\":null,\"deprecation\":null}],\"title\":null,\"entity\":{\"parent\":{\"id\":\"A2QJ37C4M7JTYGD1P2P2FVH690\",\"name\":null,\"description\":null,\"code\":null},\"picture\":null,\"type\":\"CONTACT\",\"state\":\"ACTIVE\",\"bindings\":[],\"history\":{\"createdDate\":\"2022-02-11T22:36:38.000+0000\",\"createdBy\":null,\"modifiedDate\":\"2022-02-11T22:36:38.000+0000\",\"modifiedBy\":null,\"reason\":null,\"auditSource\":null},\"source\":\"BHN_CORE\",\"inheritance\":null,\"autoCreated\":true,\"clientId\":\"QC00YVXGYKDRZ4ML8DP1LJR1GM\"},\"phoneNumbers\":[{\"id\":\"AH98P779B0S7QVD9PM625KYHD0\",\"number\":\"925-999-1111\",\"type\":\"WORK\",\"notes\":null}]}"; //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        //String pageName = obj.getJSONObject("types");
        String json="{\"webSite\":null,\"types\":[\"SITE_DELIVERY_ADDRESS\"],\"addresses\":[{\"identity\":{\"id\":\"RX8SQPAW3TL8VMDC0QQZYQL11C\",\"name\":null,\"description\":null,\"code\":null},\"type\":\"BUSINESS\",\"formattedAddress\":\"3382 Murphy Canyon Rd;San Diego, CA 92123-2654\",\"addressLine1\":\"3382 Murphy Canyon Rd\",\"addressLine2\":null,\"addressLine3\":null,\"city\":\"San Diego\",\"state\":\"CA\",\"zipCode\":\"92123-2654\",\"country\":\"USA\",\"longitude\":\"-117.1349\",\"latitude\":\"32.8084\",\"isAddressValidated\":true,\"skipMelissaData\":false}],\"preferences\":\"None\",\"emailAddresses\":[],\"identity\":{\"id\":\"6MG2M3T45JB838D16XK08PGMPH\",\"name\":\"Newwwwww\",\"description\":null,\"code\":null},\"instantMessengers\":[],\"es_metadata_id\":\"6MG2M3T45JB838D16XK08PGMPH\",\"links\":[{\"rel\":\"self\",\"href\":\"https:\\/\\/int.blackhawknetwork.com\\/channel\\/v1\\/clients\\/B6XFP5F8DR1RA659X2WWWL7X08\\/sites\\/5S4Y4BYPVRH1C35CHQ09R9P3D4\\/contacts\\/6MG2M3T45JB838D16XK08PGMPH\",\"hreflang\":null,\"media\":null,\"title\":null,\"type\":null,\"deprecation\":null}],\"title\":null,\"entity\":{\"parent\":{\"id\":\"5S4Y4BYPVRH1C35CHQ09R9P3D4\",\"name\":null,\"description\":null,\"code\":null},\"picture\":null,\"type\":\"CONTACT\",\"state\":\"ACTIVE\",\"bindings\":[],\"history\":{\"createdDate\":\"2022-02-15T08:45:30.000+0000\",\"createdBy\":\"alamo00-pp@PREPROD.LOCAL\",\"modifiedDate\":\"2022-02-15T08:45:30.000+0000\",\"modifiedBy\":\"alamo00-pp@PREPROD.LOCAL\",\"reason\":null,\"auditSource\":\"HAWKEYE_UI\"},\"source\":\"BHN_CORE\",\"inheritance\":null,\"autoCreated\":false,\"clientId\":\"B6XFP5F8DR1RA659X2WWWL7X08\"},\"phoneNumbers\":[{\"id\":\"VC1PZPK9Y61DFP5LZGYY9KS53M\",\"number\":\"342312\",\"type\":\"WORK\",\"notes\":null}]}";
        JSONObject obj2 = new JSONObject(json);

        JSONArray arr = obj.getJSONArray("types"); // notice that `"posts": [...]`
        Set<String> set = method(arr);
        JSONArray arr2 = obj2.getJSONArray("types"); //
        Set<String> set2 = method(arr2);
        System.out.println(set2.containsAll(set));*/

        String s ="  a  ";
        boolean var = s.trim().isEmpty();
        System.out.println(var);


    }

   /* private static Set<String> method(JSONArray arr ){
        Set<String> set2 = new HashSet();
        for (int i = 0; i < arr.length(); i++) {
            String post_id = arr.getString(i);
            set2.add(post_id);

        }
        return set2;
    }*/
}
