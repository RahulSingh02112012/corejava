package Cloning;

import java.util.HashMap;
import java.util.Map;

public class ShallowCopyExample implements Cloneable {

    private int id;
    private Map<Integer,Integer> map;

    public ShallowCopyExample(int id ,Map<Integer,Integer> map){
        this.id = id;
        this.map = map;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Map<Integer,Integer> map = new HashMap<>();
        map.put(10,10);
        ShallowCopyExample obj = new ShallowCopyExample(100,map);
        ShallowCopyExample clonedObj = (ShallowCopyExample) obj.clone();
        System.out.println(obj==clonedObj);
        System.out.println(obj.id == clonedObj.id);
        System.out.println(obj.map == clonedObj.map);
    }
}
