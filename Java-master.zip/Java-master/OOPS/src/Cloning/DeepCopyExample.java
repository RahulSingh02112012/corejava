package Cloning;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DeepCopyExample {
    private Integer id;
    private Map<Integer,Integer> map;

    public DeepCopyExample(int id ,Map<Integer,Integer> map){
        this.id = id;
        this.map = map;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Map<Integer,Integer> map1 = new HashMap<>();
        for (Integer key : this.map.keySet()) {
            map1.put(key, this.map.get(key));
        }
        DeepCopyExample clonedObj = new DeepCopyExample(new Integer(this.id),map1);
        return clonedObj;
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Map<Integer,Integer> map = new HashMap<>();
        map.put(10,10);
        DeepCopyExample obj = new DeepCopyExample(100,map);
        DeepCopyExample clonedObj = (DeepCopyExample)obj.clone();
        System.out.println(obj==clonedObj);
        System.out.println(obj.id == clonedObj.id);
        System.out.println(obj.map == clonedObj.map);
    }
}
