package Factory_Pattern_SQIS;

public class Isis_Document {
	
	private String Id;
	private String display_Ident;
	
	public String getId() {
		return Id;
	}
	public String getDisplay_Ident() {
		return display_Ident;
	}
	
	

}
