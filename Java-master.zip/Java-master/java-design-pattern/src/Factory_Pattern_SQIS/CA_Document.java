package Factory_Pattern_SQIS;

public class CA_Document extends Isis_Document {

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return "CA Document ID";
	}

	@Override
	public String getDisplay_Ident() {
		// TODO Auto-generated method stub
		return "CA DisplayIdent";
	}

	
	
}
