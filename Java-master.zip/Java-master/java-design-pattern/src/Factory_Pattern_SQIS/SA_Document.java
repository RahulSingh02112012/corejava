package Factory_Pattern_SQIS;

public class SA_Document extends Isis_Document {

	@Override
	public String getId() {
		return "SA Document ID";
	}

	@Override
	public String getDisplay_Ident() {
		return "SA Display Ident";
	}

	
}
