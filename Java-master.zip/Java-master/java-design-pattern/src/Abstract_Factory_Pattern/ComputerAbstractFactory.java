package Abstract_Factory_Pattern;

public interface ComputerAbstractFactory {

    public Computer createComputer();
}
