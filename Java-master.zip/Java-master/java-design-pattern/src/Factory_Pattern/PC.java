package Factory_Pattern;

public class PC implements Computer{

	@Override
	public String getHDD() {
		// TODO Auto-generated method stub
		return "PC HDD";
	}

	@Override
	public String getRAM() {
		// TODO Auto-generated method stub
		return "PC RAM";
	}

	
}
