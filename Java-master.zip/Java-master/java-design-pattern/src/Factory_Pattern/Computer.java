package Factory_Pattern;

public interface Computer {
	
	public String getHDD();
	public String getRAM();
}
