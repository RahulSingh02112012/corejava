package Atomicity;

import java.util.concurrent.atomic.AtomicInteger;

class Counter{
    private int count;
    private AtomicInteger count1 = new AtomicInteger();

    public void increment2(){
        count1.incrementAndGet();
    }
    public void increment(){
        count++;
    }

    public int getValue(){
        return count;
    }

    public int getValue2(){
        return count1.intValue();
    }
}

class IncrementThread extends Thread{
    private Counter counter;

    public IncrementThread(Counter counter){
        this.counter = counter;
    }

    public void run(){
        for(int i=0;i<10000;i++){
            counter.increment2();
        }
    }
}
public class TestAtomicity {

    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();
        IncrementThread th1 = new IncrementThread(counter);
        IncrementThread th2 = new IncrementThread(counter);
        th1.start();
        th2.start();
        th1.join();
        th2.join();
        System.out.println(counter.getValue2());
    }

}
