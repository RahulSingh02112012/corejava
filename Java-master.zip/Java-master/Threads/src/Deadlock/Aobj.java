package Deadlock;

public class Aobj {
    private Object key1 = new Object();
    private Object key2 = new Object();
    public void a(){
        System.out.println("Waiting to acquire Lock in a():-"+ Thread.currentThread().getName());
        synchronized (key1){
            System.out.println("Acquired Lock in a():-"+ Thread.currentThread().getName());
          System.out.println("Im in A-"+ Thread.currentThread().getName());
          b();
        }
    }

    public void b(){
        System.out.println("Waiting to acquire Lock in b():-"+ Thread.currentThread().getName());
        synchronized (key2){
            System.out.println("Acquired Lock in b():-"+ Thread.currentThread().getName());
            System.out.println("Im in B-"+ Thread.currentThread().getName());
           c();
        }
    }

    public void c(){
        System.out.println("Waiting to acquire Lock in c():-"+ Thread.currentThread().getName());
        synchronized (key1){
            System.out.println("Acquired Lock in c():-"+ Thread.currentThread().getName());
            System.out.println("Im in C"+ Thread.currentThread().getName());

        }
    }
}
