/**
 * 
 */
/**
 * @author rj263e
 *
 */

//1.https://www.javamadesoeasy.com/2015/03/custom-implementation-of.html
//2.https://www.javamadesoeasy.com/2015/03/implementing-threadpool-using-custom.html
//3.https://www.javamadesoeasy.com/2015/03/implement-thread-pool-in-java.html
//4.https://www.javamadesoeasy.com/2015/03/executor-and-executorservice-framework.html
//5.https://www.javamadesoeasy.com/2015/03/thread-concurrency-top-50-interview.html
//6.https://www.javamadesoeasy.com/2015/04/thread-concurrency-tutorial-in-java.html
package Deadlock;