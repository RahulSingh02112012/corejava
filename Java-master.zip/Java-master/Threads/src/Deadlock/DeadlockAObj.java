package Deadlock;

public class DeadlockAObj {

    public static void main(String[] args) {
        Aobj obj = new Aobj();
        Runnable r1=()-> obj.a();
        Runnable r2=()-> obj.b();

        Thread th1 = new Thread(r1);
        Thread th2 = new Thread(r2);
        th1.start();
        th2.start();
    }
}
