package Synchronised;

public class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public  int getAge() {
        synchronized (this){
            return age;
        }

    }

    public void setAge(int age) {
        this.age = age;
    }

    public synchronized String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
