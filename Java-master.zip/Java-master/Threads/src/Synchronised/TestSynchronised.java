package Synchronised;

public class TestSynchronised extends Thread{
    @Override
    public void run() {
        Person person = new Person("Ajay",30);
       System.out.println(person.getName()+Thread.currentThread().getName());
        System.out.println(person.getAge()+Thread.currentThread().getName());
    }

    public static void main(String[] args) {

        TestSynchronised object = new TestSynchronised();
        Thread th1 = new Thread(object,"Thread 1");
        Thread th2 = new Thread(object,"Thread 2");
        th1.start();
        th2.start();
    }
}
