package Semaphore;

import java.util.concurrent.Semaphore;

class MyThread extends Thread{

    Semaphore semaphore;
    
    public MyThread(Semaphore s) {
           semaphore=s;      
    }
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+
                " is waiting for permit");
   try {
          semaphore.acquire();
          System.out.println(Thread.currentThread().getName()+
                       " has got permit");
   
          for(int i=0;i<5;i++){
                Thread.sleep(1000);
                System.out.println(Thread.currentThread().getName()+
                              " > ");
          }
          
   } catch (InterruptedException e) {
          e.printStackTrace();
   }
   
   System.out.println(Thread.currentThread().getName()+
                " has released permit");
   semaphore.release();
		
	}
	
}
public class SemaphoreExample {

	public static void main(String[] args) {
	    // Important:- semaphores to limit the number of concurrent threads accessing a specific resource.
        //If we limit 2 then 2 threads can access a resource concurrently and it maintains a count internally
        // If counter > 0 then thread gets a access and if counter = 0 or less than then access denied
        // once thread acquired a lock and it decrease a counter and give access to thread and once released then counter increase
		Semaphore semaphore = new Semaphore(4);
		MyThread th1= new MyThread(semaphore);
		th1.start();
		MyThread th2= new MyThread(semaphore);
		th2.start();
        MyThread th3= new MyThread(semaphore);
        th3.start();
        MyThread th4= new MyThread(semaphore);
        th4.start();
		

	}

}
