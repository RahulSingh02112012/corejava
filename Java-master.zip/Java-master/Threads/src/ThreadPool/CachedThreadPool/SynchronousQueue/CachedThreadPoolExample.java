package ThreadPool.CachedThreadPool.SynchronousQueue;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MyRunnable implements Runnable {

    int taskNumber;

    MyRunnable(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    @Override
    public void run() {

        System.out.println(Thread.currentThread().getName()
                + " executing task no " + taskNumber);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}

public class CachedThreadPoolExample {
    private static int nTasks = 10;
    public static void main(String[] args) {
        // CachedThreadPool creates a thread and reuse constructed thread if they are available .if not available then it creates new thread
        //if thread is idle for 60 seconds then it gets terminated
        ExecutorService executor = Executors.newCachedThreadPool();

        for (int i = 1; i <= nTasks; i++) {
            Runnable task = new MyRunnable(i);
            System.out.println("Executing task:-" +i);
            executor.execute(task);
        }
    }
}
