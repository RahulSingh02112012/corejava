package ThreadPool.CachedThreadPool.SynchronousQueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class SynchronousQueueTest {
    static final int NUMBER_OF_CONSUMERS = 10;

    public static void main(String[] args) {
    // Synchronous Queue does not have any internal capacity , it will add element only after it takes the element
        // i.e if you add element and then next element will be added only if you take previous element using take method
        BlockingQueue<Integer> syncQueue = new SynchronousQueue<>();

        Producer producer = new Producer(syncQueue);
        producer.start();

       // Consumer[] consumers = new Consumer[NUMBER_OF_CONSUMERS];
        Consumer consumer = new Consumer(syncQueue);
        consumer.start();
        for (int i = 0; i < NUMBER_OF_CONSUMERS; i++) {

        }
    }
}
