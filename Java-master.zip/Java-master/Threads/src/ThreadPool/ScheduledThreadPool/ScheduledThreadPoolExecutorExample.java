package ThreadPool.ScheduledThreadPool;


import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class ScheduledThreadPoolExecutorExample
{
    public static void main(String[] args)
    {
        //https://localcoder.org/scheduleatfixedrate-vs-schedulewithfixeddelay
     // scheduleMethod();
       scheduleMethodAtFixedRate();
     //  scheduleMethodAtFixedDelay();
    }

    public static void  scheduleMethod(){
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);
        Task task1 = new Task ("Demo Task 1");
        Task task2 = new Task ("Demo Task 2");

        System.out.println("The time is : " + new Date());
       /* To execute a task in this scheduled executor after a period of time, you have to use the schedule() method.
         This method receives the following three parameters:

        -The task you want to execute
        -The period of time you want the task to wait before its execution
        -The unit of the period of time, specified as a constant of the TimeUnit class*/
        executor.schedule(task1, 5 , TimeUnit.SECONDS);
        executor.schedule(task2, 10 , TimeUnit.SECONDS);

        try {
            executor.awaitTermination(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        executor.shutdown();
    }

    public static void  scheduleMethodAtFixedRate() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Task task1 = new Task ("Demo Task 3");

        System.out.println("The time is : " + new Date());

        /*the scheduledAtFixedRate() method. This method accepts four parameters:

        the task you want to execute periodically,
        the delay of time until the first execution of the task,
        the period between two executions,
        and the time unit of the second and third parameters.
        */

        ScheduledFuture<?> result = executor.scheduleAtFixedRate(task1, 2, 2, TimeUnit.SECONDS);

        try {
            executor.awaitTermination(5, TimeUnit.SECONDS);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        executor.shutdown();
    }

    public static void  scheduleMethodAtFixedDelay() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Task task1 = new Task ("Demo Task 4");

        System.out.println("The time is : " + new Date());



        ScheduledFuture<?> result = executor.scheduleWithFixedDelay(task1, 2, 2, TimeUnit.SECONDS);

        try {
            executor.awaitTermination(5, TimeUnit.SECONDS);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        executor.shutdown();
    }
}
