package ExecuterService;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ExampleForUserCreatedThreadToExecutor {

    public static void main(String[] args) {

        Runnable task = ()->System.out.println("HI " +Thread.currentThread().getName());
       // Single Thread Creation
        Thread th1 = new Thread(task,"Thread Single");
        th1.start();
        System.out.println("-----------------------------------------------");
        // Multiple Thread Creation
        for(int i=0;i<10;i++){
            new Thread(task ,"Thread "+i).start();
        }
        System.out.println("-----------------------------------------------");
        // Executor Service with Single Thread Executor

        Executor service = Executors.newSingleThreadExecutor();
        service.execute(task);

        // Executor Service with Single Thread Executor
        System.out.println("-----------------------------------------------");
        Executor service2 = Executors.newSingleThreadExecutor();
        for(int i=0;i<10;i++){
            service2.execute(task);             // Only single thread execute task 10 times
        }


        System.out.println("-----------------------------------------------");
        // Executor Service with Fixed Thread Executor
        Executor service3 = Executors.newFixedThreadPool(4);
        for(int i=0;i<10;i++){
            service3.execute(task);             // 4  threads execute task 10 times
        }

        //Note:- Program will always keep running and it wont stop , so use ExecutorService.shoutdown() to stop the program
    }
}
