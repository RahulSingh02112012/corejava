package HashMap.Collision;

import java.util.HashMap;
import java.util.Map;

public class CollisionTest {

    public static void main(String[] args) {
        Map<Student,String> map = new HashMap<>();
        Student std1 = new Student(10,"Ajay");
        Student std2 = new Student(10,"Sumit");

        map.put(std1,"Ajay");     // when we put it interally calls hashcode and return id as index 10(bucket loc) of bucket which is 10 and then
                                  // stored value in linkedlist

        map.put(std2,"Sumit");   // when we put std2 it calls hashcode and return id which is 10 as bucket loc and we already have one entry at this
                                 // location and now it calls equals method to compare both keys std1 and std2
                                 // if both keys are same then std2 replace std1 but here we have different and also
                                 // check overridden equals method which compare id and name

        System.out.println(map);
        System.out.println(map.get(std1));   // while retrieving also it internally first gets hash of std1 key i.e 10 and goes to
                                             // bucket loc and now we have 2 entries at same location ,so it calls equals method and compare
                                             // both id and name in for both entries. check CustumHashMap App in hashmap package in this project
        System.out.println(map.get(std2));
    }
}
