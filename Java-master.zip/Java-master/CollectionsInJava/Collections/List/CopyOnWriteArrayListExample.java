package List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListExample {

	//http://java-latte.blogspot.com/2014/06/How-CopyOnWriteArrayList-works-in-Java-how-it-differ-from-ArrayList.html
	public static void main(String[] args) {
		List<Integer> list= new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);

		Iterator itr = list.iterator();
		while (itr.hasNext()){

			System.out.println("Before :"+list.size());
            list.add(60);
			System.out.println("After :"+list.size());
			System.out.println(itr.next());
		}
	}

}
